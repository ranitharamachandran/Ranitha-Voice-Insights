// File: src/api/axios.jsx
import axios from "axios";

const api = axios.create({
    // baseURL: "http://127.0.0.1:8000",
    baseURL: "https://speech-recognition-notes-python.onrender.com",
    timeout: 0
});

api.interceptors.request.use((config) => {
    const token = localStorage.getItem("token");
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, (error) => {
    return Promise.reject(error);
});

api.interceptors.response.use(
    (response) => response,
    (error) => {
        console.error("API Error:", error?.response || error);
        return Promise.reject(error);
    }
);

export default api;
